import 'package:flutter/material.dart';

void main() {
  runApp(const RealityDuelApp());
}

class RealityDuelApp extends StatelessWidget {
  const RealityDuelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Reality Duel',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B5CFF)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  final pages = const [
    _HomeTab(),
    _ChallengesTab(),
    _DiscoverTab(),
    _OpportunitiesTab(),
    _ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.flash_on_outlined), selectedIcon: Icon(Icons.flash_on), label: 'التحديات'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'اكتشف'),
          NavigationDestination(icon: Icon(Icons.work_outline), selectedIcon: Icon(Icons.work), label: 'الفرص'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'ملفي'),
        ],
      ),
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Reality Duel', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        const Text('العالم هو ساحتك.', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 24),
        _HeroCard(
          title: 'أظهر موهبتك',
          subtitle: 'شارك في تحديات حقيقية وابنِ ملفك أمام العالم.',
          icon: Icons.emoji_events,
          onTap: () {},
        ),
        const SizedBox(height: 18),
        const Text('ما الجديد؟', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        _InfoCard(title: 'تحديات جديدة', text: 'اكتشف تحديات تناسب مهاراتك.', icon: Icons.flash_on),
        _InfoCard(title: 'اكتشف المواهب', text: 'شاهد أصحاب المهارات والإنجازات.', icon: Icons.people),
        _InfoCard(title: 'فرص حقيقية', text: 'وظائف ومنح ورعاية وفرص تعاون.', icon: Icons.work),
      ],
    );
  }
}

class _ChallengesTab extends StatelessWidget {
  const _ChallengesTab();

  @override
  Widget build(BuildContext context) {
    return _SectionPage(
      title: 'التحديات',
      subtitle: 'اختر تحديًا وأثبت مهارتك.',
      children: const [
        _ChallengeCard(title: 'تحدي التصميم', category: 'تصميم', reward: 'فرصة ظهور'),
        _ChallengeCard(title: 'تحدي البرمجة', category: 'تقنية', reward: 'فرصة عمل'),
        _ChallengeCard(title: 'تحدي الإبداع', category: 'إبداع', reward: 'رعاية'),
      ],
    );
  }
}

class _DiscoverTab extends StatelessWidget {
  const _DiscoverTab();

  @override
  Widget build(BuildContext context) {
    return _SectionPage(
      title: 'Discover Talent',
      subtitle: 'اكتشف المواهب والمهارات.',
      children: const [
        _PersonCard(name: 'موهبة جديدة', skill: 'برمجة وتطوير'),
        _PersonCard(name: 'مبدع', skill: 'تصميم وإبداع'),
        _PersonCard(name: 'صانع محتوى', skill: 'فيديو وإعلام'),
      ],
    );
  }
}

class _OpportunitiesTab extends StatelessWidget {
  const _OpportunitiesTab();

  @override
  Widget build(BuildContext context) {
    return _SectionPage(
      title: 'Opportunities',
      subtitle: 'وظائف ومنح ورعاية وفرص تعاون.',
      children: const [
        _OpportunityCard(title: 'مطور Flutter', company: 'شركة تقنية', type: 'وظيفة'),
        _OpportunityCard(title: 'منحة إبداعية', company: 'مؤسسة', type: 'منحة'),
        _OpportunityCard(title: 'رعاية موهبة', company: 'علامة تجارية', type: 'رعاية'),
      ],
    );
  }
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
        const SizedBox(height: 12),
        const Center(child: Text('ملفي الشخصي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
        const SizedBox(height: 24),
        _InfoCard(title: 'المهارات', text: 'أضف مهاراتك وإنجازاتك.', icon: Icons.star),
        _InfoCard(title: 'الإنجازات', text: 'اعرض التحديات التي أنجزتها.', icon: Icons.emoji_events),
        _InfoCard(title: 'الفرص', text: 'تابع الفرص التي تقدمت إليها.', icon: Icons.work),
      ],
    );
  }
}

class _SectionPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Widget> children;

  const _SectionPage({required this.title, required this.subtitle, required this.children});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(subtitle),
        const SizedBox(height: 20),
        ...children,
      ],
    );
  }
}

class _HeroCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  const _HeroCard({required this.title, required this.subtitle, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Row(
            children: [
              Icon(icon, size: 52),
              const SizedBox(width: 18),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(subtitle),
              ])),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String text;
  final IconData icon;

  const _InfoCard({required this.title, required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(text),
      ),
    );
  }
}

class _ChallengeCard extends StatelessWidget {
  final String title;
  final String category;
  final String reward;

  const _ChallengeCard({required this.title, required this.category, required this.reward});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.flash_on)),
        title: Text(title),
        subtitle: Text('$category • $reward'),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      ),
    );
  }
}

class _PersonCard extends StatelessWidget {
  final String name;
  final String skill;

  const _PersonCard({required this.name, required this.skill});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text(name),
        subtitle: Text(skill),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}

class _OpportunityCard extends StatelessWidget {
  final String title;
  final String company;
  final String type;

  const _OpportunityCard({required this.title, required this.company, required this.type});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.work)),
        title: Text(title),
        subtitle: Text('$company • $type'),
        trailing: FilledButton(onPressed: () {}, child: const Text('عرض')),
      ),
    );
  }
}
