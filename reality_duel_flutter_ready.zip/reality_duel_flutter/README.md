# Reality Duel

نسخة Flutter أولية حقيقية للتطبيق، تحتوي على الهيكل الأساسي:
- الرئيسية
- التحديات
- Discover Talent
- Opportunities
- الملف الشخصي

## البناء
سيقوم GitHub Actions بتثبيت Flutter وإنشاء ملفات Android اللازمة ثم بناء APK.
