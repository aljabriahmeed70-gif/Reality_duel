import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://sdbfruxgoefdwyzhkjay.supabase.co');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (key.isEmpty) {
    runApp(const ConfigMissingApp());
    return;
  }
  await Supabase.initialize(url: url, anonKey: key);
  runApp(const RealityDuelApp());
}

class ConfigMissingApp extends StatelessWidget {
  const ConfigMissingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true),
    home: Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Supabase configuration is missing. Build with SUPABASE_PUBLISHABLE_KEY.', textAlign: TextAlign.center)))),
  );
}
