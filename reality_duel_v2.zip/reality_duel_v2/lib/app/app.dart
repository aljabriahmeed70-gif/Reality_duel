import 'package:flutter/material.dart';
import '../pages/feed_page.dart';
import '../pages/duels_page.dart';
import '../pages/discover_talent_page.dart';
import '../pages/opportunities_page.dart';
import '../pages/profile_page.dart';
import '../theme/app_theme.dart';

class RealityDuelApp extends StatefulWidget { const RealityDuelApp({super.key}); @override State<RealityDuelApp> createState()=>_RealityDuelAppState(); }
class _RealityDuelAppState extends State<RealityDuelApp> {
  Locale locale = const Locale('en'); int index=0;
  final pages=const [FeedPage(),DuelsPage(),DiscoverTalentPage(),OpportunitiesPage(),ProfilePage()];
  String t(String en,String ar)=>locale.languageCode=='ar'?ar:en;
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'Reality Duel',theme:AppTheme.dark(),locale:locale,
    home:Directionality(textDirection: locale.languageCode=='ar'?TextDirection.rtl:TextDirection.ltr,
      child:Scaffold(body:IndexedStack(index:index,children:pages),
        floatingActionButton:FloatingActionButton(onPressed:()=>showModalBottomSheet(context:context,builder:(_)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
          for(final x in const [('English','en'),('العربية','ar'),('Español','es'),('Français','fr'),('Türkçe','tr'),('中文','zh')]) ListTile(title:Text(x.$1),onTap:(){Navigator.pop(context);setState(()=>locale=Locale(x.$2));})]))),child:const Icon(Icons.language)),
        bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:[
          NavigationDestination(icon:const Icon(Icons.play_circle_outline),selectedIcon:const Icon(Icons.play_circle),label:t('Feed','الرئيسية')),
          NavigationDestination(icon:const Icon(Icons.sports_mma_outlined),selectedIcon:const Icon(Icons.sports_mma),label:t('Duels','التحديات')),
          NavigationDestination(icon:const Icon(Icons.people_outline),selectedIcon:const Icon(Icons.people),label:t('Talent','المواهب')),
          NavigationDestination(icon:const Icon(Icons.work_outline),selectedIcon:const Icon(Icons.work),label:t('Opportunities','الفرص')),
          NavigationDestination(icon:const Icon(Icons.person_outline),selectedIcon:const Icon(Icons.person),label:t('Profile','حسابي')),
        ]))));
}
