import 'package:flutter/material.dart';
import '../services/supabase_service.dart';
class AuthGate { static bool require(BuildContext context){ if(SupabaseService.signedIn)return true; showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Login required'),content:const Text('You can watch public content without login. Sign in to interact or publish.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))])); return false; } }
