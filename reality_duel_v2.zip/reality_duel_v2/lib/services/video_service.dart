import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'supabase_service.dart';
class VideoService {
  final bucket='videos';
  Future<List<Map<String,dynamic>>> feed() async { final rows=await SupabaseService.db.from('videos').select().eq('is_public',true).order('created_at',ascending:false).limit(100); return List<Map<String,dynamic>>.from(rows); }
  Future<String> upload(File file,{String caption=''}) async { final u=SupabaseService.user; if(u==null) throw const AuthException('Login required'); final ext=file.path.split('.').last.toLowerCase(); final path='${u.id}/${const Uuid().v4()}.$ext'; await SupabaseService.db.storage.from(bucket).upload(path,file); final url=SupabaseService.db.storage.from(bucket).getPublicUrl(path); await SupabaseService.db.from('videos').insert({'owner_id':u.id,'storage_path':path,'video_url':url,'caption':caption,'is_public':true}); return url; }
}
