import 'package:supabase_flutter/supabase_flutter.dart';
class SupabaseService { static SupabaseClient get db=>Supabase.instance.client; static User? get user=>db.auth.currentUser; static bool get signedIn=>user!=null; }
