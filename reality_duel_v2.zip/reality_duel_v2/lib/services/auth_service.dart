import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_service.dart';
class AuthService { Future<void> signIn(String email,String password)=>SupabaseService.db.auth.signInWithPassword(email:email,password:password); Future<void> signUp(String email,String password,String name) async { final r=await SupabaseService.db.auth.signUp(email:email,password:password,data:{'display_name':name}); if(r.user==null) throw AuthException('Sign up failed'); } Future<void> signOut()=>SupabaseService.db.auth.signOut(); }
