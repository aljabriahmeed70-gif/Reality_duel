# Reality Duel V2 Production

Real Flutter + Supabase foundation for Reality Duel.

## Features
- Public video feed without login
- Supabase Auth
- Video upload from gallery
- Supabase Storage `videos` bucket
- Likes persisted in Postgres
- Talent discovery
- Duels and joining
- Opportunities and applications
- RTL Arabic support
- APK + AAB GitHub Actions build

## Setup
1. Run `supabase/reality_duel_production.sql` in Supabase SQL Editor.
2. In GitHub repository secrets create `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`.
3. Run the GitHub Actions workflow.
4. Do not put a Supabase service-role key in the Flutter app.

## Live streaming
A production internet-scale live stream requires a WebRTC/streaming provider or self-hosted media infrastructure. This project does not fake live streaming.
